﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace fifer_auth.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult IndexUsers()
        {
            return View();
        }

        public ActionResult IndexFunctionalRoles()
        {
            return View();
        }

        public ActionResult IndexRoles()
        {
            return View();
        }

        public ActionResult IndexRules()
        {
            return View();
        }

        public ActionResult UserMenu()
        {
            return PartialView();
        }
    }
}