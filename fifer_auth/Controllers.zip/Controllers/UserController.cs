﻿using AccessModel;
using AccessRepositories;
using AuthService.FiferMembership;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using UserContext;

namespace fifer_auth.Controllers
{
    public class UserController : Controller
    {
        MembershipRepository _repository = new MembershipRepository();

        IFormsAuthenticationService FormsService { get; set; }
        IMembershipService MembershipService { get; set; }

        protected override void Initialize(RequestContext requestContext)
        {
            if (FormsService == null) { FormsService = new FormsAuthenticationService(); }
            if (MembershipService == null) { MembershipService = new AccountMembershipService(); }

            base.Initialize(requestContext);
        }
        
        public ActionResult Index(Guid userId)
        {
            var user = _repository.GetUserById(userId);
            ViewBag.LastLog = _repository.GetLastLog(userId);
            return View(user);
        }

        [HttpGet]
        public ActionResult ProfileCart(Guid usedId)
        {
            return PartialView();
        }

        [HttpPost]
        public ActionResult ProfileCart(User user)
        {
            _repository.UpdateUser(user);
            return RedirectToAction("Index", new { userId = user.UserId });
        }

        public ActionResult UserModal()
        {
            return PartialView();
        }

        public ActionResult Register(RegisterModel model)
        {
            var id = _repository.CreateUser(model);
            return Json(new { id = id }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult BlockUser(Guid userId, bool isBlock)
        {
            User user = new User();
            using (UserEntities access = new UserEntities())
            {
                user = access.Users.FirstOrDefault(mbox => mbox.UserId == userId);
                user.IsBlocked = isBlock;
                access.SaveChanges();
                if (isBlock)
                    _repository.SetLogout(userId);
            }
            return new JsonResult() { Data = new { result = true }, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
        }

        public ActionResult KickUser(Guid userId)
        {
            return new JsonResult() { Data = new { data = true }, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
        }

        public ActionResult ResetPass(Guid userId, string pass)
        {
            using (UserEntities context = new UserEntities())
            {
                var user = context.Users.FirstOrDefault(m => m.UserId == userId);
                if (string.IsNullOrEmpty(pass))
                {
                    pass = _repository.GeneratePass(8);
                }
                MembershipService.ChangePassword(user.Login, pass, pass);
            }
            return new JsonResult() { Data = new { data = true }, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
        }
    }
}