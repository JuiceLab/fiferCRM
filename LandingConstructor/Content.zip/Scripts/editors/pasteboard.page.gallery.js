﻿
function showImageDetails(imageId) {
    $.get("/PasteBoard/Editor/ImageEdit?siteId=" + $("#siteId").val() + "&itemId=" + imageId,
        function (result) {
            $("#image4Edit").html(result);
            initCropper();
        });
}

function initCropper() {
    $('#image-cropper').cropit();
    $('.select-image-btn').on("click", function () {
        $('.cropit-image-input').click();
    });

    $("#crop-save").on("click", function () {
        var data = $('#image-cropper').cropit('export', {
            type: 'image/jpeg',
            quality: .9,
            originalSize: true
        });
        $.post("/PasteBoard/ImageLoader/SaveCroped?pageId=" + $("#pageId").val() + "&siteId=" + $("#siteId").val() + "&typeId=1",
			{ "strStream": data },
			function (result) {
			    var json = $.parseJSON(result);
			    $("#Path").val(json.url);
			});
    });
}

function deleteImage(itemId) {
    $.get("/PasteBoard/Editor/DeleteImage?itemId=" + itemId + "&siteId=" + $("#siteId").val(),
        function (result) {
            $("#info-form").parents(".modal-content").html(result);
        });
}

function updateImageInfo() {
    if ($("#info-form").validate()) {
        $.post("/PasteBoard/Editor/ImageEdit?siteId=" + $("#siteId").val() + "&pageId=" + $("#pageId").val(),
            $("#info-form").serialize(),
            function (result) {
                $("#info-form").parents(".modal-content").html(result);
            })
    }
}