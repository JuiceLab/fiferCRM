﻿using LogService.FilterAttibute;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace fifer_crm.Areas.Workspace.Controllers
{
    public class HeadController : Controller
    {
        [Authorize, CRMLogAttribute]
        // GET: Workspace/Head
        public ActionResult Index()
        {
            return View();
        }
    }
}