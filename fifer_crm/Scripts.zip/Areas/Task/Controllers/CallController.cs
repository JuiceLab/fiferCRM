﻿using CompanyRepositories;
using CRMRepositories;
using EnumHelper;
using fifer_crm.Controllers;
using fifer_crm.Models;
using LogService.FilterAttibute;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TicketModel;

namespace fifer_crm.Areas.Task.Controllers
{
    [Authorize, CRMLogAttribute]
    public class CallController : BaseFiferController
    {
        public ActionResult Index()
        {
            CRMWrapViewModel model = new CRMWrapViewModel(_userId, true);
            model.Menu = GetMenu("Звонки");
            return View(model);
        }

        public ActionResult Edit(Guid? taskId, string taskNumber)
        {
            CallTicket ticket = new CallTicket()
            {
                TicketStatus = (byte)TicketStatus.Novelty,
                DateStartedStr  = DateTime.Now.AddDays(1).ToString("dd.MM.yyyy")
            };

            if(taskId.HasValue)
                ticket.Load(taskId.Value);
            ticket.OwnerId = _userId;
            StaffRepository staffRepository = new StaffRepository();
             var users = staffRepository.GetSubordinatedUsers(_userId);
             ViewBag.Assign = users;

            CRMLocalRepository repository = new CRMLocalRepository(_userId);
            ViewBag.Customers = repository.GetCustomers4Subordinate(users.Select(m=>Guid.Parse(m.Value)));
            return PartialView(ticket);
        }

        [HttpPost]
        public ActionResult Edit(CallTicket model)
        {
            CRMLocalRepository repository = new CRMLocalRepository(_userId);
            CRMLocalContext.Customer customer = repository.GetCustomerByGuid(model.ObjId.Value);
            model.Phone = customer.Phone;
            model.Save();
            return RedirectToAction("IndexEmployee", "Ordinary", new { Area = "Workspace" });
        }
    }
}