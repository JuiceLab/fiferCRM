﻿using System.Web.Mvc;

namespace fifer_crm.Areas.CRM
{
    public class CRMAreaRegistration : AreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "CRM";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) 
        {
            context.MapRoute(
                "CRM_default",
                "CRM/{controller}/{action}/{id}",
                new { controler="Customer", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}