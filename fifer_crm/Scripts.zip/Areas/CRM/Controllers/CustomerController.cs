﻿using AccessRepositories;
using AuthService.AuthorizeAttribute;
using CompanyRepositories;
using CRMModel;
using CRMRepositories;
using fifer_crm.Controllers;
using fifer_crm.Models;
using LogService.FilterAttibute;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace fifer_crm.Areas.CRM.Controllers
{
    [Authorize, CRMLogAttribute]
    public class CustomerController : BaseFiferController
    {
        public ActionResult Index()
        {
            CRMWrapViewModel model = new CRMWrapViewModel(_userId);
            model.Menu = GetMenu("Клиенты");
            return View(model);
        }

        public ActionResult CustomersList(Guid? companyId)
        {
            CRMCustomerRepository crmRepository = new CRMCustomerRepository(_userId);
            IList<CustomerViewModel> model = crmRepository.GetCustomers(companyId);
            
            List<Guid> ids = new List<Guid>();
            ids.AddRange(model.Where(m => m.AssignedBy.HasValue).Select(m => m.AssignedBy.Value).Distinct());
            
            MembershipRepository membershipRepository = new MembershipRepository();
            var names = membershipRepository.GetUserByIds(ids.Distinct());
            foreach (var item in model)
            {
                var owner = names.FirstOrDefault(m => m.UserId == item.AssignedBy);
                item.AssignedName = owner != null ? string.Format("{0} {1}", owner.FirstName, owner.LastName) : string.Empty;
            }
            return PartialView(new List<CRMCompanyViewModel>() { new CRMCompanyViewModel() { CompanyGuid = companyId.HasValue? companyId.Value: Guid.Empty, Customers = model } });
        }


        public ActionResult Edit(int? customerId, Guid? companyId)
        {
            CRMCustomerRepository repository = new CRMCustomerRepository(_userId);
            CustomerEditModel model = repository.GetCustomerEditModel(customerId, companyId);

            StaffRepository staffRepository = new StaffRepository();
            ViewBag.Assign = staffRepository.GetSubordinatedUsers(_userId);
            var items = new List<SelectListItem>() { new SelectListItem() { Text = "Физ.лицо" } };
            items.AddRange(repository.GetSelectListCompanies());
            ViewBag.Companies = items;
            return PartialView(model);
        }

        [HttpPost]
        public ActionResult Edit(CustomerEditModel model)
        {
            CRMCustomerRepository repository = new CRMCustomerRepository(_userId);
            repository.UpdateCustomer(model, _userId);
            return RedirectToAction("Index");
        }

        public ActionResult CompanyServices(int customerId)
        {
            CRMLocalRepository repository = new CRMLocalRepository(_userId);
            IEnumerable<SelectListItem> model = repository.GetSerivces4CustomerCompany(customerId); 
            return PartialView(model);
        }
    }
}