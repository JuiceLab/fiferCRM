$(function()
{
  /*
     * Multiselect
     */
    $('#multiselect-optgroup').multiSelect({ selectableOptgroup: true });
    $('#pre-selected-options').multiSelect();
    $('#Serivices, #Services').multiSelect({
    	selectableHeader: "<div class='custom-header'>Доступные услуги</div>",
    	selectionHeader: "<div class='custom-header'>Ваши услуги</div>"
    });
});