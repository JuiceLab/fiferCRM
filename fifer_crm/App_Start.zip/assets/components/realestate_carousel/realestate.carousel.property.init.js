(function($)
{

	$(window).on('load', function(){
		setTimeout(function(){
			$("#owl-property").owlCarousel({
				items: 3,
				itemsCustom : [
			        [0, 1],
			        [450, 2],
			        [600, 2],
			        [700, 3],
			        [1000, 2],
			        [1200, 3],
			        [1400, 3],
			        [1600, 3]
			    ]
			});
		}, 200);
	});

})(jQuery);