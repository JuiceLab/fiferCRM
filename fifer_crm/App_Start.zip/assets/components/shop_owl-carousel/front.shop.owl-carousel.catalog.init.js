(function($)
{

	$("#owl-catalog").owlCarousel({
		singleItem: true,
		autoPlay: 5000
	});

})(jQuery);