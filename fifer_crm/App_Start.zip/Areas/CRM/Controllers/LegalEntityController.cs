﻿using CompanyRepositories;
using CRMModel;
using CRMRepositories;
using fifer_crm.Controllers;
using fifer_crm.Models;
using FilterModel;
using LogService.FilterAttibute;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace fifer_crm.Areas.CRM.Controllers
{
    [Authorize, CRMLogAttribute]
    public class LegalEntityController : BaseFiferController
    {
        // GET: CRM/LegalEntity
        public ActionResult Index()
        {
            CRMWrapViewModel model = new CRMWrapViewModel(_userId);
            model.Menu = GetMenu("Компании");
            return View(model);
        }

        public ActionResult Edit(int? legalEnitityId)
        {
            CRMLocalRepository repository = new CRMLocalRepository(_userId);
            CRMCompanyEditModel model = repository.GetCompanyEditModel(legalEnitityId);

            StaffRepository staffRepository = new StaffRepository();
            ViewBag.Assign = staffRepository.GetSubordinatedUsers(_userId);
            ViewBag.Services = repository.GetServices(new List<int>());
            if (!legalEnitityId.HasValue)
            {
                LegalEntitySearch search = new LegalEntitySearch();
                return PartialView("NoveltyLegal", search);
            }
            return PartialView(model);
        }

        [HttpPost]
        public ActionResult NoveltyLegalEdit(LegalEntitySearch search)
        {
            CRMLocalRepository repository = new CRMLocalRepository(_userId);
            CRMCompanyEditModel model = repository.GetCompanyEditModel(null);
            model.Details[0].INN = search.INN;
            model.Details[0].KPP = search.KPP;
            model.Details[0].OGRN = search.OGRN;
            model.Details[0].RS = search.RS;
            model.LegalName = search.CompanyName;
            model.Sites = search.WebSite;
            model.Phones = search.Phone;
            model.Mails = search.EMail;

            StaffRepository staffRepository = new StaffRepository();
            ViewBag.Assign = staffRepository.GetSubordinatedUsers(_userId);
            ViewBag.Services = repository.GetServices(new List<int>());
            return PartialView("Edit", model);
        }


        [HttpPost]
        public ActionResult Edit(CRMCompanyEditModel model)
        {
            CRMLocalRepository repository= new CRMLocalRepository(_userId);
            repository.UpdateCompany(model, _userId);
            return RedirectToAction("Index");
        }

        public ActionResult CopyLocal(Guid companyId)
        {
            CRMLocalRepository repository = new CRMLocalRepository(_userId);
            repository.CopyCompanyLocal(companyId, _userId);
            return Json(new { }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult LegalSearch(LegalEntitySearch model)
        {
            CRMRepository repository = new CRMRepository();
            IEnumerable<LegalEntitySearch> items = repository.GetLegalCompanyPreviews(model);
            return PartialView(items);
        }
    }
}